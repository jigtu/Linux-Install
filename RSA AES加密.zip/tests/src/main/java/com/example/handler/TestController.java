package com.example.handler;

import com.alibaba.fastjson.JSONObject;
import com.example.model.RequestModel;
import com.example.utils.AESUtil;
import com.example.utils.RSAUtil;
import org.apache.commons.codec.binary.Base64;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.util.UUID;

/**
 * @author ZiQiang
 * @date 2019/3/14 10:00
 * 描述： <p>请写明本类的作用</p>
 */
@RestController
@RequestMapping(value = "/test")
public class TestController {

    private static Logger logger = LoggerFactory.getLogger(TestController.class);

    /**
     * 对端公钥
     */
    @Value("${public.key}")
    private String publicKey;
    /**
     * 自己的秘钥
     */
    @Value("${secret.key}")
    private String secretKey;
    /**
     * 自己的私钥
     */
    @Value("${private.key}")
    private String privateKey;

    @PostMapping(value = "/check")
    public Object test(@RequestBody RequestModel model) {
        try {
            Object analysis = analysis(model);
            return process();
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    private Object analysis(RequestModel model) throws Exception {
        String data = model.getData();
        String sign = model.getSign();
        logger.info("数据接口：" + "接收响应消息进行签名验证");
        byte[] bytes1 = Base64.decodeBase64(sign);
        String buffer = model.getPublicKeyVersion() +
                model.getClientId() + data + model.getKeyData();
        byte[] sbBytes = buffer.getBytes();
        boolean verify = RSAUtil.verify(sbBytes, bytes1, publicKey);
        if (!verify) {
            logger.info("数据接口：" + "签名验证失败!!!");
            return data;
        }
        logger.info("数据接口：" + "签名验证成功");
        logger.info("数据接口：" + "用对端私钥解析秘钥");
        String keyData = model.getKeyData();
        byte[] bytesKeyData = Base64.decodeBase64(keyData);
        // 解析出对端的秘钥（使用我方公钥加密的）
        String decipher = RSAUtil.decipher(bytesKeyData, privateKey);
        logger.info("数据接口：" + "用秘钥解析密文");
        // 生成秘钥 SecretKeySpec
        AESUtil.secretKeySpec(decipher);
        // 用秘钥解析密文 decryptData方法加载了SecretKeySpec
        String decrypt = AESUtil.decryptData(data);
        logger.info("数据接口：" + "解密后参数为=" + decrypt);
        JSONObject object = JSONObject.parseObject(decrypt);
        if (object.containsKey("params")) {
            JSONObject params = (JSONObject) object.get("params");
            logger.info("内部请求参数: " + params.toJSONString());
        }
        return "jiexi";
    }

    private Object process() throws Exception {
        JSONObject jsonYeWu = new JSONObject();
        /*parm 业务参数*/
        jsonYeWu.put("startDate", LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd")) + " 00:00:00");
        jsonYeWu.put("endDate", LocalDateTime.now().plusDays(1).format(DateTimeFormatter.ofPattern("yyyy-MM-dd")) + " 23:59:59");
        jsonYeWu.put("pageStart", 1);
        jsonYeWu.put("pageSize", 50);
        logger.info("数据接口：" + "封装业务内层参数" + jsonYeWu.toString() + "结束");

        logger.info("数据接口：" + "封装业务外层参数开始");
        JSONObject json = new JSONObject();
        json.put("service", "blacklist");
        String uuid = UUID.randomUUID().toString().replaceAll("-", "");
        json.put("requestNo", uuid);
        json.put("clientId", "-1");
        json.put("requestTime", LocalDateTime.now().toInstant(ZoneOffset.of("+8")).toEpochMilli());
        json.put("version", "0.0.1");
        json.put("params", jsonYeWu);
        logger.info("数据接口：" + "封装业务外层参数结束");

        logger.info("数据接口：" + "将业务参数加密开始");
        logger.info("数据接口：" + "生成秘钥");
        // 生成秘钥字节数组
        byte[] keyArray = RSAUtil.secretKey(secretKey);
        // Base64编码的秘钥
        String autKey = Base64.encodeBase64String(keyArray);
        AESUtil.secretKeySpec(autKey);
        // 使用秘钥加密数据 生成密文
        String encrypt = AESUtil.encryptData(json.toJSONString());
        // 生成的密文
        String encryptData = encrypt.replace("\n", "");
        logger.info("数据接口：" + "业务参数加密结束");

        logger.info("数据接口：" + "封装身份认证参数开始");
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("requestNo", uuid);
        jsonObject.put("clientId", "-1");
        jsonObject.put("publicKeyVersion", 1);
        // 用对端公钥加密秘钥
        String dataAndKeyData = RSAUtil.encipher(keyArray, publicKey);
        // 使用对端公钥加密的秘钥数据 存为keyData
        jsonObject.put("keyData", dataAndKeyData);
        // 密文封装进data
        jsonObject.put("data", encryptData);

        logger.info("数据接口：" + "封装签名");
        // 用自己的私钥签名
        String buffer = String.valueOf(jsonObject.get("publicKeyVersion")) +
                jsonObject.get("clientId") +
                jsonObject.get("data") +
                jsonObject.get("keyData");
        // 私钥签名后 Base64 编码加密
        String signKeysData = Base64.encodeBase64String(RSAUtil.sign(buffer.getBytes(), privateKey));
        /*sign签名 放在json 里面 */
        jsonObject.put("sign", signKeysData);
        logger.info("数据接口：" + "封装身份认证参数结束");
        return jsonObject;
    }
}
