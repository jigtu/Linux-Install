package com.example.handler;

import com.alibaba.fastjson.JSONObject;
import com.example.utils.AESUtil;
import com.example.utils.RSAUtil;
import org.apache.commons.codec.binary.Base64;

import java.util.Random;

/**
 * @author ZiQiang
 * @date 2019/4/23 9:41
 * 描述： <p>请写明本类的作用</p>
 */
// @RestController
// @RequestMapping(value = "/tere")
public class Trest {


    // @PostMapping(value = "/check")
    public Object tre(String Params) {
        // JSONObject object = new JSONObject();
        // object.put("code", -1);
        // object.put("message", "参数正常");
        return new JSONObject();
    }

    public static void main(String[] args) throws Exception {
        String public1 = "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAhMPT9eEPYwnHvk53cMPHirig/CCNZa67aAwxaqYbj7S8CEzsQExn2mQ7VuN/HfI1+qY5H8/D7Lo4+mSKPYpWlmV/02NGS4HH22BuMNvJcMqzOsPazr0JUPJPZCiDS11mQt4eTNNFj7an9D+an9AB0z1ALl/GBip4XZAHYN70aIbScsY9hy1RSqdJYhhUloE+R6AwezHGHwLAnDWUwcx66gSptT5jgJ12rtxq5Skr76ce21vJ+FgR+yU0HedWhuBs7qptuXUnhjLetMX6BriQ0A4vx6kh6zTHtXgXuUNo6hnrx/wXXiKgLMfeQZSzapaGSrH0cPTBxvHxA7Y6dfVn4QIDAQAB";
        String private1 = "MIIEvgIBADANBgkqhkiG9w0BAQEFAASCBKgwggSkAgEAAoIBAQCEw9P14Q9jCce+Tndww8eKuKD8II1lrrtoDDFqphuPtLwITOxATGfaZDtW438d8jX6pjkfz8Psujj6ZIo9ilaWZX/TY0ZLgcfbYG4w28lwyrM6w9rOvQlQ8k9kKINLXWZC3h5M00WPtqf0P5qf0AHTPUAuX8YGKnhdkAdg3vRohtJyxj2HLVFKp0liGFSWgT5HoDB7McYfAsCcNZTBzHrqBKm1PmOAnXau3GrlKSvvpx7bW8n4WBH7JTQd51aG4Gzuqm25dSeGMt60xfoGuJDQDi/HqSHrNMe1eBe5Q2jqGevH/BdeIqAsx95BlLNqloZKsfRw9MHG8fEDtjp19WfhAgMBAAECggEAYOReC6MNzLS1jsDLUIPBXA80hezn5J6p7NyBMBk8Ihu/4rro7GAWpv7hg58SBXPgSyYGqJ3Dmj+qF6tKbHFKkgZPTKG2CqMTjZoJsSSmFegI98k6Jgk2BFpi8HDUqSrn18MtD9pceO7QEmRc32c5/cVE0tNYvOU/5OCZUexFKQa11u8vSNL/Wida8dg7+PEei1PtSpfjqoDsClAjFZircqbswFW/1gNSczfVtQU8xB0I784Dcg7QXKlwvQpyDgLM5fGy4djZGEpOaPFpSR+Qj2/e80bOL++lHedsI4VMBQuqOraYyEPmoCG1uyOrfIQgWh86JZ5Vecynf3MDdFjlwQKBgQDJ+EQ+QqLDIbjvWxx1Dh9Y8LMC3pxLBCzKje0Xli5X+T/yzwL3Kka4PkW2fql9BdKqpjsaKPJSqVbRzR9GOdSK6Wv1RU0UZcgAUGf7frJskWtHzm0x4w6sQxWma4YKp+KxnmheCdKpkCJQ1ZzXvUZQtw/+APeH75U+CWx3KwpSqQKBgQCoSCAh9kLHVrpPS23vDyJLyDk84nbBt4pNU0/nvlQPG66V4QWEq6kex7arbNjVgJjvWeCmN9/7tUl3OY0UZ2Aq6oxkRxHBaSjoRs/p3kM/DKtcYdUCKspd5NkdpVyOccogsvKF5LzmvepY+s+Zb0fzhBotF3aV9fHthuzTBB1meQKBgQCn1UMAaedPN+qyHIhdTUsHYZ2gONSwEdwWxjHLc+U2/c0CPLw+IEd8O2M6765wUjJp1JEwf+4+erHGzim69buFY8tumhQfayTz/d0qxHIIfh8kIInk9sXuqCCJlrhginp7FyOrYYZJmZiqi5g2Pvb7g+QqMyt/LrxaPQKBVKbTYQKBgQCfnkI0VJTE5YO1APQWpEFApnt8P8arOn/JlrOdOlAbQIOaEKWeUQEKfB7NfWIzKVZm+dZ3c1pWM3+qwgEKkH+MVYuy9iJmVWwC3mAKEdOxM0A7UWStOI9Y/l/emeIwDsjNuU8HJ47yQsPNgKF3hTE3T19Q1AeceHvwdGGgSi/k6QKBgE04bOn2ubIIq3kIccvlGmzkuxPGDUuORCDFVbfM5oqGhWjq6FASEgYXT7T7pqK7UIPJZkq0Wc0HpzfvxF/wOIgTwGvhdwANADOKB23qbvtm3pW7RXWAqepqtrdRrvpbJH8+73L80N67gKWZfOdhDCCOdod/hUdocOgoaMcy43ka";
        // 公钥加密 私钥解密
        byte[] secretKey = RSAUtil.secretKey();
        System.out.println("秘钥：" + new String(secretKey));
        String autKey = Base64.encodeBase64String(secretKey);
        System.out.println("Base64加密秘钥：" + autKey);
        String encipher = RSAUtil.encipher(autKey.getBytes(), public1, 1);
        System.out.println("公钥加密数据：" + encipher);
        String decipher = RSAUtil.decipher(encipher, private1, 0);
        System.out.println("私钥解密秘钥：" + new String(Base64.decodeBase64(decipher)));

        // 私钥加密 公钥解密
        String encipher1 = RSAUtil.encipher(autKey.getBytes(), private1, 0);
        System.out.println("私钥加密秘钥：" + encipher1);
        String decipher1 = RSAUtil.decipher(encipher1, public1, 1);
        System.out.println("公钥解密秘钥：" + new String(Base64.decodeBase64(decipher1)));
    }


}
