package com.example.utils;

import org.apache.commons.codec.binary.Base64;

import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import java.nio.charset.StandardCharsets;

/**
 * @author ZiQiang
 */
public class AESUtil {

    /**
     * 密钥算法
     */
    private static final String ALGORITHM = "AES";
    /**
     * 加解密算法/工作模式/填充方式
     */
    private static final String ALGORITHM_STR = "AES/ECB/PKCS5Padding";

    /**
     * SecretKeySpec类是KeySpec接口的实现类,用于构建秘密密钥规范
     */
    private static SecretKeySpec key;

    public static void secretKeySpec(String hexKey) throws Exception {
        key = new SecretKeySpec(Base64.decodeBase64(hexKey), ALGORITHM);
    }

    /**
     * AES加密
     *
     * @param data 需要加密的数据
     * @return 加密后的数据
     * @throws Exception 异常
     */
    public static String encryptData(String data) throws Exception {
        // 创建密码器
        Cipher cipher = Cipher.getInstance(ALGORITHM_STR);
        // 初始化
        cipher.init(Cipher.ENCRYPT_MODE, key);
        return Base64.encodeBase64String(cipher.doFinal(data.getBytes(StandardCharsets.UTF_8)));
    }

    /**
     * AES解密
     *
     * @param base64Data base64Data
     * @return 解密后的数据
     * @throws Exception 异常
     */
    public static String decryptData(String base64Data) throws Exception {
        Cipher cipher = Cipher.getInstance(ALGORITHM_STR);
        cipher.init(Cipher.DECRYPT_MODE, key);
        return new String(cipher.doFinal(Base64.decodeBase64(base64Data)), StandardCharsets.UTF_8);
    }

    public static void main(String[] args) throws Exception {
        // 密钥
        AESUtil.secretKeySpec("X2Hx3q7dEPatvjwxfZHD9w==");
        byte[] decode = Base64.decodeBase64("X2Hx3q7dEPatvjwxfZHD9w==");
        System.out.println(new String(decode));
        // 加密
        System.out.println("cardNo:" + AESUtil.encryptData("{\"params\":{\"transactionAmount\":\"5005.00\",\"riskLevel\":\"高位截瘫\",\"status\":\"0\",\"riskFeature\":\"默认\",\"transactionAddress\":\"上海,杭州市\",\"transactionTime\":\"2019-01-23 14:12:44\",\"blackAccount\":\"6217998310004557469\",\"name\":\"余军伟\",\"certNo\":\"330824198811145519\",\"account\":\"13758243276\",\"telephone\":\"13758243276\",\"ccDangerId\":\"0\"},\"requestNo\":\"0\",\"requestTime\":1548223964051,\"service\":\"high.risk.trade\"}"));
        // 解密
        System.out.println("exp:" + AESUtil.decryptData("EDO1QfELcbtVL1Ys8twcmL5xXPNH/CQDPMRUmbkVVqeyMHM6RaIbPdbdxOS8g6zt9NptD4tNY8+23MYs/ru8reJ+edI0z+M1//BtrzTN9g+I7JZtkk9dDnxtTstz7KSulTSdNZcsf3LrRciif4P0BpjKk4BrOoxfZODID2/uzCscE4D19XQnJu4Uavq5s9t1QxzWZZGrB/rkIh1/nEgO/GwJdadzW6rwt64PzYOU8HWG8qZrz906Dv1/7MCUlJ8BV22oGBsZ8GgYp6dW82yte7IraOr2Vl+z1tswhAsiU2v+kLgkBo2T8l8SD7T06D10GK0WBszATKoIuAg7AqBiumWo27LHu8Rq6IgUvBKX27CcifAkGvPD1RR9BF5vsTBqy+fR/HZLbCMe3hBM+io8Ci5mVKUHKIBGhkSrDwDqyprO45aCtsovZEPpP5pE1KnEQnkFTlJVg3p8sRjwoOJnmacuKI/H4sPI8pZS35q5WVzYYNx2wchkwe1yyxgkW4UCTicjeRJCdNWM17EL5ETnvaH9j2+7Ut+owv71iDXgLMQ="));

        String encodeBase64String = Base64.encodeBase64String("你好啊啊".getBytes());
        System.out.println(new String(Base64.decodeBase64(encodeBase64String)));
    }

}