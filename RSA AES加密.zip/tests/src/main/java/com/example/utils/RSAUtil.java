package com.example.utils;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.io.output.ByteArrayOutputStream;

import javax.crypto.*;
import java.nio.charset.StandardCharsets;
import java.security.*;
import java.security.interfaces.RSAPrivateKey;
import java.security.interfaces.RSAPublicKey;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * @author ZiQiang
 */
public class RSAUtil {

    private static final String SIGNATURE_ALGORITHM = "SHA256withRSA";

    /**
     * RSA密钥长度必须是64的倍数，在512~65536之间。默认是1024
     * 1024长度 加密117 解密128， 2048长度 加解密都是256（偏移量）
     */
    private static final int KEY_SIZE = 2048;

    /**
     * 签名
     *
     * @param data       数据
     * @param privateKey 自己的私钥
     * @return 签名后的byte数组
     * @throws Exception 异常
     */
    public static byte[] sign(byte[] data, String privateKey) throws Exception {
        Signature sig = Signature.getInstance(SIGNATURE_ALGORITHM);
        sig.initSign(getPrivateKey(privateKey));
        sig.update(data);
        return sig.sign();
    }

    /**
     * 校验
     *
     * @param data      校验的数据
     * @param sign      签名
     * @param publicKey 对端提供的公钥
     * @return 校验是否成功
     * @throws Exception 异常
     */
    public static boolean verify(byte[] data, byte[] sign, String publicKey) throws Exception {
        Signature sig = Signature.getInstance(SIGNATURE_ALGORITHM);
        sig.initVerify(getPublicKey(publicKey));
        sig.update(data);
        return sig.verify(sign);
    }

    /**
     * 生成秘钥
     */
    public static byte[] secretKey(String key) throws Exception {
        KeyGenerator kg = KeyGenerator.getInstance("AES");
        // 要生成多少位，只需要修改这里即可128, 192或256
        kg.init(128, new SecureRandom(key.getBytes(StandardCharsets.UTF_8)));
        return kg.generateKey().getEncoded();
    }

    /**
     * 生成秘钥
     */
    public static byte[] secretKey() throws Exception {
        KeyGenerator kg = KeyGenerator.getInstance("AES");
        // 要生成多少位，只需要修改这里即可128, 192或256
        kg.init(128);
        return kg.generateKey().getEncoded();
    }

    /**
     * 生成公钥、私钥对(keySize=1024)
     */
    public static Map<String, String> getKeyPair() {
        return getKeyPair(KEY_SIZE);
    }

    /**
     * 生成公钥、私钥对
     *
     * @param keySize RSA密钥长度
     * @return KeyPairInfo
     */
    private static Map<String, String> getKeyPair(int keySize) {
        try {
            Map<String, String> hashMap = new ConcurrentHashMap<>(2);
            KeyPairGenerator keyPairGen = KeyPairGenerator.getInstance("RSA");
            keyPairGen.initialize(keySize);
            // 生成一个密钥对，保存在keyPair中
            KeyPair keyPair = keyPairGen.generateKeyPair();
            // 得到私钥
            RSAPrivateKey privateKey = (RSAPrivateKey) keyPair.getPrivate();
            // 得到公钥
            RSAPublicKey publicKey = (RSAPublicKey) keyPair.getPublic();
            //公钥
            byte[] publicKeyByte = publicKey.getEncoded();
            String publicKeyString = Base64.encodeBase64String(publicKeyByte);
            hashMap.put("publicKey", publicKeyString);
            //私钥
            byte[] privateKeyByte = privateKey.getEncoded();
            String privateKeyString = Base64.encodeBase64String(privateKeyByte);
            hashMap.put("privateKey", privateKeyString);
            return hashMap;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    /**
     * 得到公钥对象
     *
     * @param publicKeyBase64 密钥字符串（经过base64编码）
     * @throws Exception 异常
     */
    public static PublicKey getPublicKey(String publicKeyBase64) throws Exception {
        byte[] keyBytes = Base64.decodeBase64(publicKeyBase64);
        X509EncodedKeySpec keySpec = new X509EncodedKeySpec(keyBytes);
        KeyFactory keyFactory = KeyFactory.getInstance("RSA");
        return keyFactory.generatePublic(keySpec);
    }

    /**
     * 得到私钥对象
     *
     * @param privateKeyBase64 密钥字符串（经过base64编码）
     * @throws Exception 异常
     */
    public static PrivateKey getPrivateKey(String privateKeyBase64) throws Exception {
        byte[] keyBytes = Base64.decodeBase64(privateKeyBase64);
        PKCS8EncodedKeySpec keySpec = new PKCS8EncodedKeySpec(keyBytes);
        KeyFactory keyFactory = KeyFactory.getInstance("RSA");
        return keyFactory.generatePrivate(keySpec);
    }

    /**
     * 解密
     *
     * @param base64Bytes 待解密内容 Base64 编码
     * @param keyBase64   公/私钥 Base64 编码
     * @param flag        0 私钥解密 1 公钥解密
     * @return 解密后的数据
     */
    public static String decipher(String base64Bytes, String keyBase64, Integer flag) {
        try {
            byte[] bytes = Base64.decodeBase64(base64Bytes);
            if (flag == 0) {
                PrivateKey key = getPrivateKey(keyBase64);
                return decipher(bytes, key);
            } else {
                PublicKey key = getPublicKey(keyBase64);
                return decipher(bytes, key);
            }
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    /**
     * @param data 待解密数据
     * @param key  公/私钥
     * @return 解密数据
     */
    private static String decipher(byte[] data, Key key) throws Exception {
        Cipher cipher = Cipher.getInstance(key.getAlgorithm());
        cipher.init(Cipher.DECRYPT_MODE, key);
        return Base64.encodeBase64String(init(data, cipher));
    }


    /**
     * @param content   明文数据
     * @param keyBase64 公私/钥
     * @param flag      0 私钥加密 1 公钥加密
     * @return 加密后的密文
     */
    public static String encipher(byte[] content, String keyBase64, Integer flag) {
        try {
            Key key;
            if (flag == 0) {
                key = getPrivateKey(keyBase64);
            } else {
                key = getPublicKey(keyBase64);
            }
            return encipher(content, key);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    /**
     * 公/私钥加密
     *
     * @param content 公私/钥
     * @param key     明文数据
     * @return 加密后的密文
     * @throws Exception 加密过程中的异常信息
     */
    private static String encipher(byte[] content, Key key) throws Exception {
        try {
            // 使用默认RSA
            Cipher cipher = Cipher.getInstance(key.getAlgorithm());
            cipher.init(Cipher.ENCRYPT_MODE, key);
            return Base64.encodeBase64String(init(content, cipher));
        } catch (NoSuchAlgorithmException e) {
            throw new Exception("无此加密算法");
        } catch (NoSuchPaddingException e) {
            e.printStackTrace();
            return null;
        } catch (InvalidKeyException e) {
            throw new Exception("加密公/私钥非法,请检查");
        } catch (IllegalBlockSizeException e) {
            throw new Exception("明文长度非法");
        } catch (BadPaddingException e) {
            throw new Exception("明文数据已损坏");
        }
    }

    private static byte[] init(byte[] bytes, Cipher cipher) throws Exception {
        int inputLen = bytes.length;
        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        int offSet = 0, i = 0;
        byte[] cache;
        // 对数据分段加解密
        while (inputLen - offSet > 0) {
            if (inputLen - offSet > 256) {
                cache = cipher.doFinal(bytes, offSet, 256);
            } else {
                cache = cipher.doFinal(bytes, offSet, inputLen - offSet);
            }
            outputStream.write(cache, 0, cache.length);
            i++;
            offSet = i * 256;
        }
        byte[] byteArray = outputStream.toByteArray();
        outputStream.close();
        return byteArray;
    }


    public static void main(String[] args) {
        try {
            // byte[] bytes = secretKey("1234567");
            // for (byte aByte : bytes) {
            //     System.out.print(aByte + " ");
            // }
            // System.out.println();
            // String base64String = Base64.encodeBase64String(bytes);
            // System.out.println(base64String);
            // byte[] bytes1 = Base64.decodeBase64(base64String);
            // for (byte aByte : bytes1) {
            //     System.out.print(aByte + " ");
            // }
            // System.out.println();

            Map<String, String> map = getKeyPair();
            System.out.println(map.get("privateKey"));
            System.out.println(map.get("publicKey"));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
