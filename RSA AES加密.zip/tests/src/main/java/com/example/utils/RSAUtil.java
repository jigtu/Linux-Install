package com.example.utils;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.io.output.ByteArrayOutputStream;

import javax.crypto.*;
import java.nio.charset.StandardCharsets;
import java.security.*;
import java.security.interfaces.RSAPrivateKey;
import java.security.interfaces.RSAPublicKey;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * @author ZiQiang
 */
public class RSAUtil {

    private static final String SIGNATURE_ALGORITHM = "SHA256withRSA";

    /**
     * RSA密钥长度必须是64的倍数，在512~65536之间。默认是1024
     */
    public static final int KEY_SIZE = 2048;

    /**
     * 签名
     *
     * @param data             数据
     * @param privateKeyBase64 自己的私钥
     * @return 签名后的byte数组
     * @throws Exception 异常
     */
    public static byte[] sign(byte[] data, String privateKeyBase64) throws Exception {
        Signature sig = Signature.getInstance(SIGNATURE_ALGORITHM);
        sig.initSign(getPrivateKey(privateKeyBase64));
        sig.update(data);
        return sig.sign();
    }

    /**
     * 校验
     *
     * @param data         校验的数据
     * @param sign         签名
     * @param aliPublicKey 对端提供的公钥
     * @return 校验是否成功
     * @throws Exception 异常
     */
    public static boolean verify(byte[] data, byte[] sign, String aliPublicKey) throws Exception {
        Signature sig = Signature.getInstance(SIGNATURE_ALGORITHM);
        sig.initVerify(getPublicKey(aliPublicKey));
        sig.update(data);
        return sig.verify(sign);
    }

    /**
     * 生成秘钥
     */
    public static byte[] secretKey(String key) throws Exception {
        KeyGenerator kg = KeyGenerator.getInstance("AES");
        // 要生成多少位，只需要修改这里即可128, 192或256
        kg.init(128, new SecureRandom(key.getBytes(StandardCharsets.UTF_8)));
        return kg.generateKey().getEncoded();
    }

    /**
     * 生成公钥、私钥对(keySize=1024)
     */
    public static Map<String, String> getKeyPair() {
        return getKeyPair(KEY_SIZE);
    }

    /**
     * 生成公钥、私钥对
     *
     * @param keySize RSA密钥长度
     * @return KeyPairInfo
     */
    private static Map<String, String> getKeyPair(int keySize) {
        try {
            Map<String, String> hashMap = new ConcurrentHashMap<>(2);
            KeyPairGenerator keyPairGen = KeyPairGenerator.getInstance("RSA");
            keyPairGen.initialize(keySize);
            // 生成一个密钥对，保存在keyPair中
            KeyPair keyPair = keyPairGen.generateKeyPair();
            // 得到私钥
            RSAPrivateKey privateKey = (RSAPrivateKey) keyPair.getPrivate();
            // 得到公钥
            RSAPublicKey publicKey = (RSAPublicKey) keyPair.getPublic();
            //公钥
            byte[] publicKeyByte = publicKey.getEncoded();
            String publicKeyString = Base64.encodeBase64String(publicKeyByte);
            hashMap.put("publicKey", publicKeyString);
            //私钥
            byte[] privateKeyByte = privateKey.getEncoded();
            String privateKeyString = Base64.encodeBase64String(privateKeyByte);
            hashMap.put("privateKey", privateKeyString);
            return hashMap;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    /**
     * 得到公钥对象
     *
     * @param publicKeyBase64 密钥字符串（经过base64编码）
     * @throws Exception 异常
     */
    public static PublicKey getPublicKey(String publicKeyBase64) throws Exception {
        byte[] keyBytes = Base64.decodeBase64(publicKeyBase64);
        X509EncodedKeySpec keySpec = new X509EncodedKeySpec(keyBytes);
        KeyFactory keyFactory = KeyFactory.getInstance("RSA");
        return keyFactory.generatePublic(keySpec);
    }

    /**
     * 得到私钥对象
     *
     * @param privateKeyBase64 密钥字符串（经过base64编码）
     * @throws Exception 异常
     */
    public static PrivateKey getPrivateKey(String privateKeyBase64) throws Exception {
        byte[] keyBytes = Base64.decodeBase64(privateKeyBase64);
        PKCS8EncodedKeySpec keySpec = new PKCS8EncodedKeySpec(keyBytes);
        KeyFactory keyFactory = KeyFactory.getInstance("RSA");
        return keyFactory.generatePrivate(keySpec);
    }

    /**
     * 使用公钥加密
     *
     * @param content         待加密内容
     * @param publicKeyBase64 公钥 base64 编码
     * @return 经过base64 编码后的字符串
     */
    public static String encipher(byte[] content, String publicKeyBase64) {
        return encipher(content, publicKeyBase64, KEY_SIZE / 8 - 11);
    }

    /**
     * 使用公钥加密（分段加密）
     *
     * @param content         待加密内容
     * @param publicKeyBase64 公钥 base64 编码
     * @param segmentSize     分段大小,一般小于 keySize/8（段小于等于0时，将不使用分段加密）
     * @return 经过 base64 编码后的字符串
     */
    public static String encipher(byte[] content, String publicKeyBase64, int segmentSize) {
        try {
            PublicKey publicKey = getPublicKey(publicKeyBase64);
            return encipher(content, publicKey, segmentSize);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    /**
     * 分段加密
     *
     * @param cipherText  密文
     * @param key         加密秘钥
     * @param segmentSize 分段大小，<=0 不分段
     * @return 加密后的数据
     */
    public static String encipher(byte[] cipherText, Key key, int segmentSize) {
        try {
            // 用公钥加密
            // Cipher负责完成加密或解密工作，基于RSA
            Cipher cipher = Cipher.getInstance("RSA");
            // 根据公钥，对Cipher对象进行初始化
            cipher.init(Cipher.ENCRYPT_MODE, key);
            if (segmentSize > 0) {
                // 分段加密
                return Base64.encodeBase64String(cipherDoFinal(cipher, cipherText, segmentSize));
            } else {
                // 不分段加密
                return Base64.encodeBase64String(cipher.doFinal(cipherText));
            }
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    /**
     * 分段加密
     *
     * @param cipher      密码
     * @param srcBytes    待加密数据字节数组
     * @param segmentSize 分段大小
     * @return 加密后的数据
     * @throws Exception 异常
     */
    public static byte[] cipherDoFinal(Cipher cipher, byte[] srcBytes, int segmentSize) throws Exception {
        if (segmentSize <= 0) {
            throw new RuntimeException("分段大小必须大于0");
        }
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        int inputLen = srcBytes.length;
        int offSet = 0;
        byte[] cache;
        int i = 0;
        // 对数据分段解密
        while (inputLen - offSet > 0) {
            if (inputLen - offSet > segmentSize) {
                cache = cipher.doFinal(srcBytes, offSet, segmentSize);
            } else {
                cache = cipher.doFinal(srcBytes, offSet, inputLen - offSet);
            }
            out.write(cache, 0, cache.length);
            i++;
            offSet = i * segmentSize;
        }
        byte[] data = out.toByteArray();
        out.close();
        return data;
    }

    /**
     * 使用私钥解密
     *
     * @param contentBase64    待加密内容,Base64 编码
     * @param privateKeyBase64 私钥 Base64 编码
     * @return 解密后的数据
     */
    public static String decipher(byte[] contentBase64, String privateKeyBase64) {
        return decipher(contentBase64, privateKeyBase64, KEY_SIZE / 8);
    }

    /**
     * 加密
     *
     * @param data   要加密的数据字节数组
     * @param pubKey 对端公钥
     * @return 加密后的字节数组
     * @throws Exception 异常
     */
    public byte[] encrypt(byte[] data, String pubKey) throws Exception {
        PublicKey publicKey = getPublicKey(pubKey);
        Cipher cipher = Cipher.getInstance("RSA");
        cipher.init(Cipher.ENCRYPT_MODE, publicKey);
        return cipher.doFinal(data);
    }

    /**
     * @param data   要解密的数据
     * @param priKey 自己的私钥
     * @return 解密后的字节数据
     * @throws Exception 异常
     */
    public byte[] decrypt(byte[] data, String priKey) throws Exception {
        PrivateKey privateKey = getPrivateKey(priKey);
        Cipher cipher = Cipher.getInstance("RSA");
        cipher.init(Cipher.DECRYPT_MODE, privateKey);
        return cipher.doFinal(data);
    }

    /**
     * 使用私钥解密（分段解密）
     *
     * @param contentBase64    待加密内容,Base64 编码
     * @param privateKeyBase64 私钥 Base64 编码
     * @return
     * @segmentSize 分段大小
     */
    public static String decipher(byte[] contentBase64, String privateKeyBase64, int segmentSize) {
        try {
            PrivateKey privateKey = getPrivateKey(privateKeyBase64);
            return decipher(contentBase64, privateKey, segmentSize);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    /**
     * 分段解密
     *
     * @param contentBase64 密文
     * @param key           解密秘钥
     * @param segmentSize   分段大小（小于等于0不分段）
     * @return 解密后的数据
     */
    public static String decipher(byte[] contentBase64, Key key, int segmentSize) {
        try {
            // 用私钥解密
            // Cipher负责完成加密或解密工作，基于RSA
            Cipher deCipher = Cipher.getInstance("RSA");
            // 根据公钥，对Cipher对象进行初始化
            deCipher.init(Cipher.DECRYPT_MODE, key);
            if (segmentSize > 0) {
                //分段加密
                return Base64.encodeBase64String(cipherDoFinal(deCipher, contentBase64, segmentSize));
            } else {
                return Base64.encodeBase64String(deCipher.doFinal(contentBase64));
            }
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    /**
     * 公钥加密
     *
     * @param publicKey     公钥
     * @param plainTextData 明文数据
     * @return 加密后的密文
     * @throws Exception 加密过程中的异常信息
     */
    public String encrypt(RSAPublicKey publicKey, byte[] plainTextData) throws Exception {
        if (publicKey == null) {
            throw new Exception("加密公钥为空, 请设置");
        }
        try {
            // 使用默认RSA
            Cipher cipher = Cipher.getInstance("RSA");
            cipher.init(Cipher.ENCRYPT_MODE, publicKey);
            return Base64.encodeBase64String(cipher.doFinal(plainTextData));
        } catch (NoSuchAlgorithmException e) {
            throw new Exception("无此加密算法");
        } catch (NoSuchPaddingException e) {
            e.printStackTrace();
            return null;
        } catch (InvalidKeyException e) {
            throw new Exception("加密公钥非法,请检查");
        } catch (IllegalBlockSizeException e) {
            throw new Exception("明文长度非法");
        } catch (BadPaddingException e) {
            throw new Exception("明文数据已损坏");
        }
    }


    public static void main(String[] args) {
        try {
            byte[] bytes = secretKey("1234567");
            for (byte aByte : bytes) {
                System.out.print(aByte + " ");
            }
            System.out.println();
            String base64String = Base64.encodeBase64String(bytes);
            System.out.println(base64String);
            byte[] bytes1 = Base64.decodeBase64(base64String);
            for (byte aByte : bytes1) {
                System.out.print(aByte + " ");
            }
            System.out.println();

            Map<String, String> map = getKeyPair();
            System.out.println(map);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
