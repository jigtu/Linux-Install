package com.example.utils;

import com.alibaba.fastjson.JSON;
import okhttp3.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.util.concurrent.TimeUnit;


/**
 * 发送rest请求，用于反馈结果
 *
 * @author ZiQiang
 */
public class RequestUtil {
    public static final Logger logger = LoggerFactory.getLogger(RequestUtil.class);

    /**
     * 通过okhttp3 发送post请求
     *
     * @param obj 参数类型为对象，会使用JSON.toJSONString(obj);进行转换
     * @param url 请求地址
     * @return 返回结果
     */
    public static String send(Object obj, String url) {
        String json = JSON.toJSONString(obj);
        return send(json, url);
    }

    /**
     * 通过okhttp3 发送post请求
     *
     * @param json 参数为json字符串
     * @param url  请求地址
     * @return 返回结果
     */
    public static String send(String json, String url) {
        // logger.info("发送数据为：" + json);
        RequestBody body = RequestBody.create(MEDIA_TYPE, json);
        Request request = new Request.Builder().url(url).post(body).build();
        try {
            Response response = HTTP_CLIENT.newCall(request).execute();
            if (!response.isSuccessful()) {
                throw new IOException("Unexpected code " + response);
            } else {
                assert response.body() != null;
                return response.body().string();
            }
        } catch (IOException e) {
            logger.error("异常：" + e);
            e.printStackTrace();
            return null;
        }
    }

    /**
     * okhttp3的超时设置
     */
    private final static int CONNECT_TIMEOUT = 15;
    private final static int READ_TIMEOUT = 100;
    private final static int WRITE_TIMEOUT = 60;
    /**
     * 设置请求头为application/json 发送json数据
     */
    private static final MediaType MEDIA_TYPE = MediaType.parse("application/json; charset=utf-8");
    private static final OkHttpClient HTTP_CLIENT = new OkHttpClient.Builder()
            //设置读取超时时间
            .readTimeout(READ_TIMEOUT, TimeUnit.SECONDS)
            //设置写的超时时间
            .writeTimeout(WRITE_TIMEOUT, TimeUnit.SECONDS)
            //设置连接超时时间
            .connectTimeout(CONNECT_TIMEOUT, TimeUnit.SECONDS)
            .build();
}
