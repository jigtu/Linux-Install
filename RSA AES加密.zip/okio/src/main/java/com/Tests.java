package com;

import java.util.Scanner;

/**
 * @author xingyu.tu
 * @date 2019/3/21
 * 描述： 计算梯形的面积
 */
public class Tests {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        // 定义上底 下底 高的变量 输入后按回车
        double upperBottom, lowerBottom, high;
        System.out.print(" 请输入梯形的上底：");
        upperBottom = scanner.nextDouble();
        System.out.print(" 请输入梯形的下底： ");
        lowerBottom = scanner.nextDouble();
        System.out.print(" 请输入梯形的高： ");
        high = scanner.nextDouble();
        System.out.println(" 梯形的面积为：" + (upperBottom + lowerBottom) * high / 2);

    }
}
