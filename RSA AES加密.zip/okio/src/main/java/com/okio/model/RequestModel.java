package com.okio.model;

/**
 * @author ZiQiang
 * @date 2019/3/15 10:04
 * 描述： <p>请写明本类的作用</p>
 */
public class RequestModel {

    /**
     * 请求编号（一般使用uuid）
     */
    private String requestNo;
    /**
     * 客户端id
     */
    private String clientId;
    /**
     * 公钥版本
     */
    private String publicKeyVersion;
    /**
     * 秘钥加密后的数据
     */
    private String data;
    /**
     * 加密后的秘钥
     */
    private String keyData;
    /**
     * 签名
     */
    private String sign;

    public String getRequestNo() {
        return requestNo;
    }

    public void setRequestNo(String requestNo) {
        this.requestNo = requestNo;
    }

    public String getClientId() {
        return clientId;
    }

    public void setClientId(String clientId) {
        this.clientId = clientId;
    }

    public String getPublicKeyVersion() {
        return publicKeyVersion;
    }

    public void setPublicKeyVersion(String publicKeyVersion) {
        this.publicKeyVersion = publicKeyVersion;
    }

    public String getData() {
        return data;
    }

    public void setData(String data) {
        this.data = data;
    }

    public String getKeyData() {
        return keyData;
    }

    public void setKeyData(String keyData) {
        this.keyData = keyData;
    }

    public String getSign() {
        return sign;
    }

    public void setSign(String sign) {
        this.sign = sign;
    }
}
