package com.okio.model;

import java.time.LocalDateTime;
import java.time.ZoneOffset;

/**
 * @author ZiQiang
 * @date 2019/3/15 10:18
 * 描述： <p>请写明本类的作用</p>
 */
public class OuterParams {
    /**
     *
     */
    private String service;
    /**
     * 请求编号 （uuid）
     */
    private String requestNo;
    /**
     * 客户端id
     */
    private String clientId;
    /**
     * 请求时间 1552616650126
     */
    private String requestTime;
    /**
     * 版本号
     */
    private String version;
    /**
     * 内部请求参数
     */
    private String params;

    public static void main(String[] args) {
        System.out.println(LocalDateTime.now().toInstant(ZoneOffset.of("+8")).toEpochMilli());
    }

    public String getService() {
        return service;
    }

    public void setService(String service) {
        this.service = service;
    }

    public String getRequestNo() {
        return requestNo;
    }

    public void setRequestNo(String requestNo) {
        this.requestNo = requestNo;
    }

    public String getClientId() {
        return clientId;
    }

    public void setClientId(String clientId) {
        this.clientId = clientId;
    }

    public String getRequestTime() {
        return requestTime;
    }

    public void setRequestTime(String requestTime) {
        this.requestTime = requestTime;
    }

    public String getVersion() {
        return version;
    }

    public void setVersion(String version) {
        this.version = version;
    }

    public String getParams() {
        return params;
    }

    public void setParams(String params) {
        this.params = params;
    }
}
