package com.okio.handler;

import com.alibaba.fastjson.JSONObject;
import com.okio.rsa.AESUtil;
import com.okio.rsa.RSAUtil;
import com.okio.util.RequestUtil;
import org.apache.commons.codec.binary.Base64;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.util.UUID;

/**
 * @author ZiQiang
 * @date 2019/3/13 16:48
 * 描述： <p>请写明本类的作用</p>
 */
// @RestController
// @RequestMapping(value = "/test")
public class TestHandler {
    private static Logger logger = LoggerFactory.getLogger(TestHandler.class);

    /**
     * 自己的秘钥
     */
    // @Value("${secret.key}")
    private static String secretKey = "Trfdgg#etgvh";

    /**
     * 自己的私钥
     */
    // @Value("${private.key}")
    private static String privateKey = "MIIEvgIBADANBgkqhkiG9w0BAQEFAASCBKgwggSkAgEAAoIBAQCTJ35Kj0NAm4KqyDZiGjLaXU9BWsgbXJxz7nBpksW8jhAbMUmJ7CnyCi83lNIaySErw2A3F91HWRvCGr+a01qLxXpNAr/PVGGrT73YpcWhKN+u1TtRsMsIYwmipYcoQ+LBOyx2wQMa8qOchRXfTeGP6zDj6ruTn3w9SIqOIp7pplDi28Wh8m93rwSdDATDejo6sxWX6QUmTefJ06QPfUqhxFW+34kIyqo5/dmKZN2ao1UpJJDKeZmsGSxu9f0V6kiykIV5rPhwnF8gbUhBKu1q48E6bKCJ68T8/O8vKMroUdjZsGrJ7rbqXKqsFwaygP+LIRCvloHuUrAVprkjsy/RAgMBAAECggEBAII2iEJh0xjwgwescrMMi8M+nksukbPkl2zeqQpCnkbjTs1BJ9mr6NIMwQtl3SVmpLuc/x7BN0VTTITONo5CR/U2oapTrHdCK8rznQKAbgjVqlmCxiLbVk3tlTEfWCIBMD3cptPOp3jJDI4MFfara9V2QKTtqV5P2hhAgJqVeBk3f+Huxb9W1ng7V+nReuH9yW5mzMSZGHibgt5vyO03rlEQ3sinE2fQfBx/VPALI0on+tUlbnZQ9sU3jqXIJqoQe0tlMdPM17lLn0sGDC5o33PEA+sEXJUvrC4YgFs063q0Rh/+kLrQ3eJKGpYUa8FGgw80BkEzqrgn778mGDwxU4ECgYEA3kne7g57Jha7pLTer+PdKxgwHNPeIa6NQvU/agQ6QHR1bv1scvCzqG29kKMwt276Dj+pV03+fEIDnh9Fn2GkIce0D0+rOFw5x3jR5OeghZBQLhn+OVYzry/tPnT5ovsAPoIAUlbTb+O4tfs6QZjnL7qwzdZQ5SxWsmAiDt1aLkUCgYEAqXicC2RMxtuXqQ6qHWDCH/87DlQRQhrkJ9dbcVNWaYZXabuq1MQOy+uPfY+WGUrdjotCWeOal/daOhijR59V/CIyraPQnH1365HUSM7xAX1mTVAR/CefW8UzXZQycjJTZnsfpzAJMWYrDOGH+FE2WFFOyyRzFL3yWbWQJTJsSh0CgYBVjEx1hbEzWXBh1RIW0zUdDrQFhCxq/ghzinsbTAE3KRrA2ltQaP5bhdB8x7FKBzXJIgsEBIo6PBW0VwiubB+EuJy9f8W/bQ73i7ILzHDktkOFWo+SdXByrZk6fj5M0Rio9dM13SCGYTeHIeartDLVFZ5RuXdsm4HKKGEzI1E/mQKBgQCbjnXNjxdaQR6Is0k7BiGqNSEEGe5tezmJyIfLEe/zlLiP+Q7plbzvOR3Q5wej17Besz0IPX8dlpJfWVYm2/6VHN7fu8o0moaE2Kq+2hUmhPBubtzTU5tXJT/s2ackY0VigAmh8Nm/WkSR4kJokEMN9jQZCzAHDgNyjNHvEsWLkQKBgG0lkiPTeT7j+LImGADBgsQBataOPuY4JOtqUQW0Nn8bd+qUcjNyJCL+jV2PNaed1h4Gx8LUQrjp8OMkKxYZKjXn6AYJrlRJN/0jvHpT+1LQlZOJPMHDyIn6yq2KlaQOUElj7vIzEjaGzEEMYO4Aquo/VmM5POUtGKB3OBGd2zev";
    /**
     * 对端公钥
     */
    // @Value("${public.key}")
    private static String publicKey = "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAiSmwKRlB0ByZCK9xe0wq1ockxhLsxSYSjHLFgI9o53GS4Q5+cVojDGfhXkGk5yJJINiMjfWkWaqd5acyI50PwV2WMXJwLjQYMv7wFNVhVI8578xlYjBbXIFLfsBvAp5SXXkxB1f/XdNX1GUUbQ96WaajkATT8Vsv3R4Ahfu3U1Eqmbx5jpI+9hLbfUGf1nJGvinxSwdfrjsZq/gfAx7FbvmPF+74G0PWG7RYpOiASIfrdnKLy2Pq5wew+7NnNFtn79+QVU7wJXDZlebtlu1NACg+/vwGVMmaDMezrgDOOCUipv3epEgDuYgw5nFu8+IsGfkzfkQOj5TlvGWNCkGDRQIDAQAB";

    public static void main(String[] args) {
        try {
            String result = process();
            String send = RequestUtil.send(result, "http://localhost:8090/test/check");

            // System.out.println(result);
            // JSONObject parseObject = JSONObject.parseObject(result);
            // if (parseObject.containsKey("data")) {
            //     String sign = (String) parseObject.get("sign");
            //     logger.debug("数据接口：" + "接收响应消息进行签名验证");
            //     byte[] bytes1 = RSAUtil.decodeBase64(sign);
            //     String buffer = String.valueOf(parseObject.get("publicKeyVersion")) +
            //             parseObject.get("clientId") +
            //             parseObject.get("data") +
            //             parseObject.get("keyData");
            //     byte[] sbBytes = buffer.getBytes();
            //     boolean verify = RSAUtil.verify(sbBytes, bytes1, publicKey);
            //     if (!verify) {
            //         logger.debug("数据接口：" + "签名验证失败!!!");
            //         return;
            //     }
            //     logger.debug("数据接口：" + "签名验证成功");
            //     logger.debug("数据接口：" + "用对端私钥解析秘钥");
            //     String keyData = (String) parseObject.get("keyData");
            //     byte[] bytesKeyData = RSAUtil.decodeBase64(keyData);
            //     // 解析出对端的秘钥（使用我方公钥加密的） 我方私钥
            //     String decipher = RSAHelper.decipher(bytesKeyData, privateKey);
            //     logger.debug("数据接口：" + "用秘钥解析密文");
            //     String data = (String) parseObject.get("data");
            //     // 生成秘钥 SecretKeySpec
            //     AESUtil.secretKeySpec(decipher);
            //     // 用秘钥解析密文 decryptData方法加载了SecretKeySpec
            //     String decrypt = AESUtil.decryptData(data);
            //     logger.debug("数据接口：" + "解密后参数为=" + decrypt);
            //     JSONObject object = JSONObject.parseObject(decrypt);
            //     if (object.containsKey("params")) {
            //         JSONObject params = (JSONObject) object.get("params");
            //         System.out.println(params.toJSONString());
            //     }
            //     // 下面就是解析参数的逻辑了
            //     System.out.println();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static String process() throws Exception {
        JSONObject jsonYeWu = new JSONObject();
        /*parm 业务参数*/
        jsonYeWu.put("startDate", LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd")) + " 00:00:00");
        jsonYeWu.put("endDate", LocalDateTime.now().plusDays(1).format(DateTimeFormatter.ofPattern("yyyy-MM-dd")) + " 23:59:59");
        jsonYeWu.put("pageStart", 1);
        jsonYeWu.put("pageSize", 50);
        logger.debug("数据接口：" + "封装业务内层参数" + jsonYeWu.toString());
        logger.debug("数据接口：" + "封装业务内层参数结束");

        logger.debug("数据接口：" + "封装业务外层参数开始");
        JSONObject json = new JSONObject();
        json.put("service", "blacklist");
        String uuid = UUID.randomUUID().toString().replaceAll("-", "");
        json.put("requestNo", uuid);
        json.put("clientId", "-1");
        json.put("requestTime", LocalDateTime.now().toInstant(ZoneOffset.of("+8")).toEpochMilli());
        json.put("version", "0.0.1");
        logger.debug("数据接口：" + "将业务内层参数封装进外层参数里面");
        json.put("params", jsonYeWu);
        logger.debug("数据接口：" + "封装业务外层参数结束");

        logger.debug("数据接口：" + "将业务参数加密开始");
        logger.debug("数据接口：" + "生成秘钥");
        // 生成秘钥字节数组
        byte[] keyArray = RSAUtil.secretKey(secretKey);
        // Base64编码的秘钥
        String autKey = Base64.encodeBase64String(keyArray);
        AESUtil.secretKeySpec(autKey);
        //
        String encrypt = AESUtil.encryptData(json.toJSONString());
        logger.debug("数据接口：" + "用秘钥给 业务参数加密生成密文");
        String encryptData = encrypt.replace("\n", "");
        logger.debug("数据接口：" + "将业务参数加密结束");


        logger.debug("数据接口：" + "封装身份认证参数开始");
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("requestNo", uuid);
        jsonObject.put("clientId", "-1");
        jsonObject.put("publicKeyVersion", 1);
        logger.debug("数据接口：" + "将密文封装进身份认证");
        jsonObject.put("data", encryptData);
        logger.debug("数据接口：" + "用对端公钥加密我方秘钥");
        String dataAndKeyData = RSAUtil.encipher(keyArray, publicKey);
        // 使用对端公钥加密的我方秘钥 存为keyData
        jsonObject.put("keyData", dataAndKeyData);

        logger.debug("数据接口：" + "封装签名");
        // 用自己的私钥签名
        String buffer = String.valueOf(jsonObject.get("publicKeyVersion")) +
                jsonObject.get("clientId") +
                jsonObject.get("data") +
                jsonObject.get("keyData");
        byte[] bytesData = RSAUtil.sign(buffer.getBytes(), privateKey);
        String signKeysData = Base64.encodeBase64String(bytesData);
        /*sign签名 放在json 里面 */
        jsonObject.put("sign", signKeysData);
        logger.debug("数据接口：" + "封装身份认证参数结束");
        return jsonObject.toJSONString();
    }
}
