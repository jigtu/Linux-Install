package com.okio.handler;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.okio.model.RequestModel;
import com.okio.rsa.AESUtil;
import com.okio.rsa.RSAUtil;
import com.okio.util.RequestUtil;
import org.apache.commons.codec.binary.Base64;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.util.UUID;

/**
 * @author ZiQiang
 * @date 2019/3/14 10:00
 * 描述： <p>请写明本类的作用</p>
 */
// @RestController
// @RequestMapping(value = "/test")
public class TestHandler {

    private static Logger logger = LoggerFactory.getLogger(TestHandler.class);

    /**
     * 对端公钥
     */
    private static final String PUBLIC_KEY = "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAp6rNseQndrss4pT12wthY52c1UrlR1D1ovL62f66ZiJoG2in1GICJBsrWGc7/DJrvvvxS0cwsOBlgG9CMbseGk1Qg2crmE2yM6mfayk/ZcrbYeOGtk/pWgH2y3CfTZb0Laj64s8B2jw9yt0GhseOsJb1UIgYhB9f6Uu38aRHnWY7AsHmf0+ch+aNOVXtbt+IJYtbbP3n/tMsDqXnVtFbiMsBmCWLwyIuv3XjYiLzFJQJ6/G0oQ5wwlamzyqOiA6qmEi2OHIuYaDjepwRBERxEyZfrKKRJVfXgiMOGkJnJfIC7xKwbOisRnt0TIiExnIbZ9wn0IxbrX4e8p7u34xUmwIDAQAB";
    /**
     * 自己的秘钥
     */
    private static final String SECRET_KEY = "123456";
    /**
     * 自己的私钥
     */
    private static final String PRIVATE_KEY = "MIIEvQIBADANBgkqhkiG9w0BAQEFAASCBKcwggSjAgEAAoIBAQDBUlOTy2RhuD+NuXT2Gnuo1aP0KxDIEfcNcf9wiyyPuyWUnWLhSi7Uej2O30bA4wLNjqpr6Th6dRzqKFr4CTU8r02YIRKNgZ9A3IhkfwtWEbAqpoJQ24+k3TMq2E85VX3/UA2vJDg/UUT/OvMHCkK1IrHPaYKEmjMdxDoVojFSWer6QNAFwW5aCBvAvN9U9UoFWPmFOr2nxC0fD4R0bgWWFpP5av0FipGLO4IH3gH7Ob31GvGBPQMGA3l4jGBMfqPEq/aRbAKcb6zZcNV1v/grKSB8h3P4Zy8m9q4840J8AcbVlVsOiaBM6uEB7U1cOu9FszuW0ntw45fGFDXrNGu/AgMBAAECggEAMBQ0ev5Lkc4L6EhmYUqG1J+FbhVD0C4/nhVq7OeABqMJnqNh0xvq96cLJjw7UX9j1BGWKs5O4I29yjKNJUDM/7Gtf5dCEPVa0PvH5A6AmEA/6uuMX2WrnNnyfsZbNawgcN3M+XDtmDmzCjLz/B0+J+RgCnB4KFhdPBrwQy8aSxtpIDh+NvUr6p6kcpUed+3verXHzr4qxagxt6mfZzUngPIMJM7UtVPt5mH4iKThrAquVmMJmHjq34pn/5z8dUtfqSl/OT3oFEEdl8I6n6HcMzH1nIEebUlKu0ZCgT4ARt7YCel6RCFA2lb+Mmjkea1KvnM6onoU20reylaMuGQ7YQKBgQDfWS6cu8rI/GrXF6RXk1Jw89NETzRyU/6T0NR18bjIsdVge5QCmtlGmTJKHLxdUPUV5VdahGPVTqA/GAnug1fAOQRBeQFwBoUAHjc5gvhlxBWbTe/qi6/n5NRIwzo3aUvgfn0czEdX7T6U+2Q/x77+sm78rSgrA6y+7xS91b0gLwKBgQDdlWQ2eGLBc8BvGI5L9gbQMylYeMMH7vfajXWsGK4wr6Uf2FNBaFee8Fd8M1voyQwfdhH3JoZ6f4fs9ZyIJbqDylZTd8y7q9cDOpuAbspWv6B9Lhv5mBH7p3UAEPf51FKOw8J/qrLqCAB5rY6FTTY2SOGPgeGciMyTXeVFDe15cQKBgQCd+8JJ4VfmZQ3ZyYJY4/97oCy/c9sgR6OawSuXpfzUEV5iWedvFEM+edylqb/frgU+kLQCdgT7/BrDpmhYCxXGBU6qVUKcEDCBzd24U5kKuvGhojZjTJ2HxUgXk+iZC2U9jZtIBIMugcUzssLNjqfeFy8EkiMIkhfeEtU0Fn0pxwKBgFXgCvmNSIC+0op70tIfpF5WJaTzEGrns0kRX9R1sDSQLgeceA+2V5bygIVTBkC+giNDSA0n8iBRgqVUPvkI3jMrXK92k3L8UxUeRpvM1EAwfgtlrlPaGsYUDSUcbm51WhWYSq3dwv8uYLjHiZ+h3+vD7R8H8B8RaW+HiU5s6mcRAoGAC7uFAl/8iFnsr77al2qZYIaHk7WkT5m+pO/e2cAm2l7J+6+K6TjWrvcY61joebDtuTp3+SMt1rt9+9cGeIJLyIbR1WHoySC0Cdhu0aDS6oUQwtVGhYMwy0vqfFiBRL/v9WbRi9Spkxbtk7ZJN3FUVrbXhFgIAAcGWVjZxEaAvBc=";

    public Object test(@RequestBody RequestModel model) {
        try {
            Object analysis = analysis(model);
            return process();
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    private static Object analysis(RequestModel model) throws Exception {
        String data = model.getData();
        String sign = model.getSign();
        logger.info("数据接口：" + "签名验证");
        byte[] bytes1 = Base64.decodeBase64(sign);
        String buffer = model.getPublicKeyVersion() +
                model.getClientId() + data + model.getKeyData();
        byte[] sbBytes = buffer.getBytes();
        boolean verify = RSAUtil.verify(sbBytes, bytes1, PUBLIC_KEY);
        if (!verify) {
            logger.info("数据接口：" + "验签失败!!!");
            return data;
        }
        logger.info("数据接口：" + "验签成功");
        logger.info("数据接口：" + "解析秘钥");
        String keyData = model.getKeyData();
        byte[] bytesKeyData = Base64.decodeBase64(keyData);
        // 解析出对端的秘钥（使用我方公钥加密的）
        String decipher = RSAUtil.decipher(bytesKeyData, PRIVATE_KEY);
        logger.info("数据接口：" + "解析密文");
        // 生成秘钥 SecretKeySpec
        AESUtil.secretKeySpec(decipher);
        // 用秘钥解析密文 decryptData方法加载了SecretKeySpec
        String decrypt = AESUtil.decryptData(data);
        logger.info("数据接口：" + "解密后参数为= " + decrypt);
        JSONObject object = JSONObject.parseObject(decrypt);
        String key = "params";
        if (object.containsKey(key)) {
            JSONObject params = (JSONObject) object.get(key);
            logger.info("内部请求参数: " + params.toJSONString());
            return params;
        }
        return object;
    }

    private static Object process() throws Exception {
        JSONObject jsonYeWu = new JSONObject();
        /*parm 业务参数*/
        jsonYeWu.put("startDate", LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd")) + " 00:00:00");
        jsonYeWu.put("endDate", LocalDateTime.now().plusDays(1).format(DateTimeFormatter.ofPattern("yyyy-MM-dd")) + " 23:59:59");
        jsonYeWu.put("pageStart", 1);
        jsonYeWu.put("pageSize", 50);
        logger.info("数据接口：" + "封装业务内层参数" + jsonYeWu.toString() + "结束");

        logger.info("数据接口：" + "封装业务外层参数开始");
        JSONObject json = new JSONObject();
        json.put("service", "blacklist");
        String uuid = UUID.randomUUID().toString().replaceAll("-", "");
        json.put("requestNo", uuid);
        json.put("clientId", "-1");
        json.put("requestTime", LocalDateTime.now().toInstant(ZoneOffset.of("+8")).toEpochMilli());
        json.put("version", "0.0.1");
        json.put("params", jsonYeWu);
        logger.info("数据接口：" + "封装业务外层参数结束");

        logger.info("数据接口：" + "将业务参数加密开始");
        logger.info("数据接口：" + "生成秘钥");
        // 生成秘钥字节数组
        byte[] keyArray = RSAUtil.secretKey(SECRET_KEY);
        // Base64编码的秘钥
        String autKey = Base64.encodeBase64String(keyArray);
        AESUtil.secretKeySpec(autKey);
        // 使用秘钥加密数据 生成密文
        String encrypt = AESUtil.encryptData(json.toJSONString());
        // 生成的密文
        String encryptData = encrypt.replace("\n", "");
        logger.info("数据接口：" + "业务参数加密结束");

        logger.info("数据接口：" + "封装身份认证参数开始");
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("requestNo", uuid);
        jsonObject.put("clientId", "-1");
        jsonObject.put("publicKeyVersion", 1);
        // 用对端公钥加密秘钥
        String dataAndKeyData = RSAUtil.encipher(keyArray, PUBLIC_KEY);
        // 使用对端公钥加密的秘钥数据 存为keyData
        jsonObject.put("keyData", dataAndKeyData);
        // 密文封装进data
        jsonObject.put("data", encryptData);

        logger.info("数据接口：" + "封装签名");
        // 用自己的私钥签名
        String buffer = String.valueOf(jsonObject.get("publicKeyVersion")) +
                jsonObject.get("clientId") +
                jsonObject.get("data") +
                jsonObject.get("keyData");
        // 私钥签名后 Base64 编码加密
        String signKeysData = Base64.encodeBase64String(RSAUtil.sign(buffer.getBytes(), PRIVATE_KEY));
        /*sign签名 放在json 里面 */
        jsonObject.put("sign", signKeysData);
        logger.info("数据接口：" + "封装身份认证参数结束");
        return jsonObject;
    }


    public static void main(String[] args) throws Exception {
        Object process = process();
        String send = RequestUtil.send(process, "http://localhost:8090/test/check");
        System.out.println(send);
        analysis(JSON.parseObject(send, RequestModel.class));
    }
}
